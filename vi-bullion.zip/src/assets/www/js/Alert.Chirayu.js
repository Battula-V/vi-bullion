
function alert1(strMessage)
{


		navigator.notification.alert(
                strMessage,         // message
                null,                 // callback
                'Alert',           // title
                'Ok'                  // buttonName
            );
			

}

