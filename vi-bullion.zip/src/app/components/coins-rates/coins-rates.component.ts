import { Component } from '@angular/core';

@Component({
  selector: 'app-coins-rates',
  templateUrl: './coins-rates.component.html',
  styleUrls: ['./coins-rates.component.scss']
})
export class CoinsRatesComponent {

}
