import { Component } from '@angular/core';

@Component({
  selector: 'app-live-rates',
  templateUrl: './live-rates.component.html',
  styleUrls: ['./live-rates.component.scss']
})
export class LiveRatesComponent {

}
